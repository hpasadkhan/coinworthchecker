
import { config } from 'dotenv';
config();

import '@/ai/flows/estimate-coin-value.ts';
import '@/ai/schemas';
